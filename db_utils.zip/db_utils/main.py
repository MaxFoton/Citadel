import sys
import logging
from db_operations import add_private_key_field, drop_nodes_table

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("main")


def main():
    print("\n===== Database Operations =====")
    print("1. Add private_key field to nodes table")
    print("2. Drop nodes table completely")
    print("0. Exit")

    try:
        choice = input("\nChoose an operation (0-2): ")

        if choice == "0":
            print("Exiting program.")
            return True

        if choice not in ["1", "2"]:
            logger.error("Invalid choice. Please enter 0, 1, or 2.")
            return False

        print("\nEnter database connection details:")
        db_type = input("Database type (sqlite/postgres): ").lower()

        if db_type == "sqlite":
            db_path = input("Database file path (e.g., ./database.sqlite3): ")
            db_url = f"sqlite://{db_path}"
        elif db_type == "postgres":
            host = input("Host (default: localhost): ") or "localhost"
            port = input("Port (default: 5432): ") or "5432"
            user = input("Username: ")
            password = input("Password: ")
            dbname = input("Database name: ")
            db_url = f"postgres://{user}:{password}@{host}:{port}/{dbname}"
        else:
            logger.error("Unsupported database type. Use 'sqlite' or 'postgres'.")
            return False

        if choice == "1":
            logger.info("Adding private_key field to nodes table...")
            success = add_private_key_field(db_url)
        else:
            confirm = input("\nWARNING: This will permanently delete the nodes table. Type 'YES' to confirm: ")
            if confirm.upper() != "YES":
                logger.info("Operation cancelled.")
                return True

            logger.info("Dropping nodes table...")
            success = drop_nodes_table(db_url)

        return success

    except KeyboardInterrupt:
        logger.info("\nOperation cancelled by user.")
        return True
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return False


if __name__ == "__main__":
    success = main()
    input("\nPress Enter to exit...")
    sys.exit(0 if success else 1)
