import logging
import sys
import os
import sqlite3
import re

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("db_operations")


def add_private_key_field_sqlite(db_path):
    if not os.path.exists(db_path):
        logger.error(f"Database file not found: {db_path}")
        return False

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='nodes';")
        if not cursor.fetchone():
            logger.error("Table 'nodes' does not exist in the database.")
            conn.close()
            return False

        cursor.execute("PRAGMA table_info(nodes);")
        columns = cursor.fetchall()
        column_names = [column[1] for column in columns]

        if 'private_key' in column_names:
            logger.info("Field 'private_key' already exists in table 'nodes'. No action needed.")
            conn.close()
            return True

        cursor.execute("ALTER TABLE nodes ADD COLUMN private_key TEXT;")
        conn.commit()
        logger.info("Successfully added field 'private_key' to table 'nodes'.")
        conn.close()
        return True

    except sqlite3.Error as e:
        logger.error(f"SQLite error: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return False


def add_private_key_field_postgres(db_url):
    try:
        import psycopg2
        from psycopg2 import sql
    except ImportError:
        logger.error("psycopg2 is not installed. Install it with: pip install psycopg2-binary")
        return False

    match = re.match(r'postgres://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)', db_url)
    if not match:
        logger.error("Invalid PostgreSQL URL format. Expected: postgres://user:pass@host:port/dbname")
        return False

    user, password, host, port, dbname = match.groups()

    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            dbname=dbname
        )
        conn.autocommit = True
        cursor = conn.cursor()

        cursor.execute("""
        SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = 'nodes'
        );
        """)
        if not cursor.fetchone()[0]:
            logger.error("Table 'nodes' does not exist in the database.")
            conn.close()
            return False

        cursor.execute("""
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_schema = 'public' AND table_name = 'nodes' AND column_name = 'private_key';
        """)
        if cursor.fetchone():
            logger.info("Field 'private_key' already exists in table 'nodes'. No action needed.")
            conn.close()
            return True

        cursor.execute("ALTER TABLE nodes ADD COLUMN private_key TEXT;")
        logger.info("Successfully added field 'private_key' to table 'nodes'.")
        conn.close()
        return True

    except psycopg2.Error as e:
        logger.error(f"PostgreSQL error: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return False


def add_private_key_field(db_url):
    if db_url.startswith('sqlite://'):
        path = db_url.replace('sqlite://', '')
        if path.startswith('./'):
            path = path[2:]

        return add_private_key_field_sqlite(path)
    elif db_url.startswith('postgres://'):
        return add_private_key_field_postgres(db_url)
    else:
        logger.error("Unsupported database type. Use 'sqlite://' or 'postgres://' prefix.")
        return False


def drop_nodes_table_sqlite(db_path):
    if not os.path.exists(db_path):
        logger.error(f"Database file not found: {db_path}")
        return False

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='nodes';")
        if not cursor.fetchone():
            logger.error("Table 'nodes' does not exist in the database. Nothing to drop.")
            conn.close()
            return False

        cursor.execute("DROP TABLE nodes;")
        conn.commit()
        logger.info("Successfully dropped table 'nodes'.")
        conn.close()
        return True

    except sqlite3.Error as e:
        logger.error(f"SQLite error: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return False


def drop_nodes_table_postgres(db_url):
    try:
        import psycopg2
        from psycopg2 import sql
    except ImportError:
        logger.error("psycopg2 is not installed. Install it with: pip install psycopg2-binary")
        return False

    match = re.match(r'postgres://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)', db_url)
    if not match:
        logger.error("Invalid PostgreSQL URL format. Expected: postgres://user:pass@host:port/dbname")
        return False

    user, password, host, port, dbname = match.groups()

    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            dbname=dbname
        )
        conn.autocommit = True
        cursor = conn.cursor()

        cursor.execute("""
        SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = 'nodes'
        );
        """)
        if not cursor.fetchone()[0]:
            logger.error("Table 'nodes' does not exist in the database. Nothing to drop.")
            conn.close()
            return False

        cursor.execute("DROP TABLE nodes;")
        logger.info("Successfully dropped table 'nodes'.")
        conn.close()
        return True

    except psycopg2.Error as e:
        logger.error(f"PostgreSQL error: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return False


def drop_nodes_table(db_url):
    if db_url.startswith('sqlite://'):
        path = db_url.replace('sqlite://', '')
        if path.startswith('./'):
            path = path[2:]

        return drop_nodes_table_sqlite(path)
    elif db_url.startswith('postgres://'):
        return drop_nodes_table_postgres(db_url)
    else:
        logger.error("Unsupported database type. Use 'sqlite://' or 'postgres://' prefix.")
        return False
